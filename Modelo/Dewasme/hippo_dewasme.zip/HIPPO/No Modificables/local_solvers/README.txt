You may need commercial or special licenses to use some of these packages.
Commercial local solvers, like e.g. FSQP are, therefore, not distributed
with SSm. For the others, please read their license agreements from their
provided web links (these agreements which might change with time).
